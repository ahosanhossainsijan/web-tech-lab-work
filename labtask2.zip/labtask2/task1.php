<?php
  
  $length=50;
  $width=30;
  $area=($length*$width);
  $parameter=2*($length+$width);
   echo "The area is : ".$area."<br>";
echo "The pramameter is : ".$parameter."<br>";

?>