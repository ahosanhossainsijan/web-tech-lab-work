<?php
  $amount =1000;
  $VAT=.15;
  echo "Vat amount for ".$amount." is : ".($amount*$VAT);
?>