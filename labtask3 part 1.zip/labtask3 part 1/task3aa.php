<?php 
$month=_POST['month'];
$day=_POST['day'];
$year=_POST['year'];
$birthday=$month.'-'.$day.'-'.$year;

echo $birthday;
 ?>