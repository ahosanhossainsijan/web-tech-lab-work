<!DOCTYPE html>
<html>
<body>
<form action="task2aa.php" method="post"> 
	Email : <input type="text" name="email"><br>
	<input type="submit" name="submit" value="Submit">
</form>
</body>
</html>